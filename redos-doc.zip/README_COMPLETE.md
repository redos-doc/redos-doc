# demoexam_complete

Исправленная учебная версия архива автоматизации.

## Что добавлено и исправлено

1. Добавлены bootstrap-скрипты статической адресации Linux и начальной настройки Eltex.
2. Добавлен `preinstall.yml` для недостающих пакетов.
3. Исправлены физические интерфейсы Eltex:
   - HQ-RTR: 1/0/2 ISP, 1/0/3 HQ-SRV, 1/0/4 HQ-CLI
   - BR-RTR: 1/0/2 ISP, 1/0/3 BR-SRV
4. HQ-CLI-Net изменена на `/27`, чтобы сеть гарантированно вмещала не менее 16 хостов.
5. Для `net_admin` на Eltex используется `password ascii-text P@ssw0rd`.
6. RAID создаётся как `/dev/md0`, затем создаётся раздел `/dev/md0p1`, ext4 и `/raid`.
7. DNS `docker` и `web` сделаны A-записями на интерфейсы ISP по таблице задания.
8. Основной Docker-контейнер называется `tespapp`.
9. Вариативная часть вынесена отдельно в `site-variative.yml`.
10. Перед Nextcloud стек testapp останавливается: оба задания используют порт 8080 BR-SRV.

## Порядок запуска

### 1. С консоли машин
- Выполнить `bootstrap/isp-network.sh` на ISP.
- Выполнить `bootstrap/hq-srv-network.sh` на HQ-SRV.
- Выполнить `bootstrap/br-srv-network.sh` на BR-SRV.
- Ввести команды из `bootstrap/eltex-initial.txt` на Eltex.
- На ISP выполнить `bash isp.sh`.

### 2. Пакеты
```bash
ansible-playbook preinstall.yml
```

### 3. Основной Модуль 1
```bash
ansible-playbook site-module1.yml
```

### 4. HQ-CLI получает DHCP
На HQ-CLI выполнить:
```bash
bash bootstrap/hq-cli-dhcp.sh
```

### 5. Основной Модуль 2
```bash
ansible-playbook site-module2.yml
```

### 6. Вариативная часть
Сначала проверить testapp из Модуля 2, затем:
```bash
ansible-playbook site-variative.yml
```

## Важная оговорка Samba

Архив настраивает Samba file server с локальными пользователями `hquser1..5`.
Если эксперт трактует пункт 1.5 как вход пользователей в ОС HQ-CLI, а не
аутентификацию к Samba-ресурсу с HQ-CLI, потребуется отдельная настройка
Samba AD DC и ввод HQ-CLI в домен. В исходном архиве этого нет.
