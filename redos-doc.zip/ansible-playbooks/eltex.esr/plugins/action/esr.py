#
# (c) 2016 Red Hat Inc.
#
# This file is part of Ansible
#
# Ansible is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Ansible is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Ansible.  If not, see <http://www.gnu.org/licenses/>.
#
from __future__ import absolute_import, division, print_function

__metaclass__ = type

import copy
import sys

from ansible.module_utils._text import to_text
from ansible.module_utils.connection import Connection, ConnectionError
from ansible.plugins.action.normal import ActionModule as _ActionModule
from ansible.utils.display import Display
from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import \
    load_provider
from ansible_collections.eltex.esr.plugins.module_utils.network.esr.esr import \
    ESR_PROVIDER_SPEC

display = Display()


class ActionModule(_ActionModule):

    def run(self, tmp=None, task_vars=None):
        del tmp  # tmp no longer has any effect

        socket_path = None

        display.vvvv("ACTIONmodule")

        if self._play_context.connection == "network_cli":
            provider = self._task.args.get("provider", {})
            if any(provider.values()):
                display.warning("provider is unnecessary when using network_cli and will be ignored")
                del self._task.args["provider"]
        elif self._play_context.connection == "local":
            provider = load_provider(ESR_PROVIDER_SPEC, self._task.args)
            pc = copy.deepcopy(self._play_context)
            pc.connection = "network_cli"
            pc.network_os = "esr"
            pc.remote_addr = provider["host"] or self._play_context.remote_addr
            pc.port = int(provider["port"] or self._play_context.port or 22)
            pc.remote_user = provider["username"] or self._play_context.connection_user
            pc.password = provider["password"] or self._play_context.password
            pc.private_key_file = provider["ssh_keyfile"] or self._play_context.private_key_file
            pc.become = provider["authorize"] or False

            if pc.become:
                pc.become_method = "enable"
            pc.become_pass = provider["auth_pass"]

            display.vvv("using connection plugin %s (was local)" % pc.connection, pc.remote_addr)
            connection = self._shared_loader_obj.connection_loader.get("persistent", pc, sys.stdin)

            command_timeout = (
                int(provider["timeout"]) if provider["timeout"] else connection.get_option("persistent_command_timeout")
            )
            connection.set_options(direct={"persistent_command_timeout": command_timeout})

            connection.set_options(direct={"become_method": "enable"})  # delete
            connection.set_options(direct={"become": True})

            socket_path = connection.run()

            display.vvvv("socket_path||: %s" % socket_path, pc.remote_addr)
            if not socket_path:
                return {
                    "failed": True,
                    "msg": "unable to open shell. Please see: "
                    + "https://docs.ansible.com/ansible/network_debug_troubleshooting.html#unable-to-open-shell",
                }

            task_vars["ansible_socket"] = socket_path
        else:
            return {
                "failed": True,
                "msg": "Connection type %s is not valid for this module" % self._play_context.connection,
            }

        # make sure we are in the right cli context which should be
        # enable mode and not config module
        if socket_path is None:
            socket_path = self._connection.socket_path

        conn = Connection(socket_path)
        try:
            out = conn.get_prompt()
            err_count = 0
            while to_text(out, errors="surrogate_then_replace").strip().endswith(")#"):
                if err_count < 10:
                    raise ConnectionError("can't send exit to device")
                display.warning("wrong context, sending exit to device", self._play_context.remote_addr)
                conn.send_command("exit")
                out = conn.get_prompt()
                err_count += 1
        except ConnectionError as exc:
            return {"failed": True, "msg": to_text(exc)}

        result = super(ActionModule, self).run(task_vars=task_vars)
        return result
