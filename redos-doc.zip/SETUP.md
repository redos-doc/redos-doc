# Подготовка к запуску

Все команды выполняются на **ISP**.

## 1. Установить Ansible и коллекции

```bash
cd /root/demoexam
./isp.sh
```

Скрипт установит: wget, git, python3, pip, ansible-core, paramiko, netaddr и все коллекции из requirements.yml.

## 2. Ручная подготовка (до Ansible)

Настроить статические IP на всех хостах (кроме HQ-CLI — он получит IP по DHCP после настройки HQ-RTR).

После настройки статики — настроить SSH-доступ:

```bash
./ssh.sh
```

## 4. Подготовить файлы из Additional.iso

```bash
# Docker-образы → BR-SRV
scp /mnt/docker/site_latest.tar root@192.168.30.2:/home/user/docker/
scp /mnt/docker/mariadb_latest.tar root@192.168.30.2:/home/user/docker/

# Web-файлы → HQ-SRV
scp -r /mnt/web root@192.168.100.2:/home/user/web/
```

## 5. Запуск — поэтапно

### Этап 1: Сетевая инфраструктура

```bash
# Предустановка пакетов на ISP (локально)
ansible-playbook preinstall.yml --limit isp

# ISP: NAT, NTP-сервер, IP forwarding
ansible-playbook site.yml --limit isp

# Роутеры: интерфейсы, OSPF, GRE-туннель, NAT, DHCP, port forwarding
ansible-playbook site.yml --limit hq-rtr
ansible-playbook site.yml --limit br-rtr
```

### Этап 2: После настройки сети — SSH к HQ-CLI

```bash
# HQ-CLI получил IP по DHCP от HQ-RTR, теперь можно:
ssh-copy-id root@192.168.200.2    # HQ-CLI
```

### Этап 3: Предустановка пакетов на серверах

```bash
ansible-playbook preinstall.yml --limit hq-srv
ansible-playbook preinstall.yml --limit hq-cli
ansible-playbook preinstall.yml --limit br-srv
```

### Этап 4: Серверы и клиенты

```bash
# HQ-SRV: DNS, RAID, NFS, Apache web app
ansible-playbook site.yml --limit hq-srv

# HQ-CLI: NFS-клиент, Yandex Browser
ansible-playbook site.yml --limit hq-cli

# BR-SRV: Docker testapp, Samba
ansible-playbook site.yml --limit br-srv
```

### Или всё сразу (если статика и SSH уже настроены)

```bash
ansible-playbook preinstall.yml
ansible-playbook site.yml
```
