#!/bin/bash
set -e
nmcli con show
# Replace profile names below if your stand differs.
nmcli con mod "Проводное подключение 1" connection.id WAN
nmcli con mod "Проводное подключение 2" connection.id ISP-HQ
nmcli con mod "Проводное подключение 3" connection.id ISP-BR
nmcli con mod WAN ipv4.method auto ipv4.never-default no ipv6.method disabled
nmcli con mod ISP-HQ ipv4.method manual ipv4.addresses 172.16.1.1/28 ipv4.never-default yes ipv6.method disabled
nmcli con mod ISP-BR ipv4.method manual ipv4.addresses 172.16.2.1/28 ipv4.never-default yes ipv6.method disabled
nmcli con up WAN
nmcli con up ISP-HQ
nmcli con up ISP-BR
ip -br a
ip r
