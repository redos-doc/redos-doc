#!/bin/bash
set -e
nmcli con show
nmcli con mod "Проводное подключение 1" connection.id HQ-SRV
nmcli con mod HQ-SRV ipv4.method manual ipv4.addresses 192.168.100.2/27 ipv4.gateway 192.168.100.1 ipv4.dns 192.168.100.2 ipv6.method disabled
nmcli con up HQ-SRV
ip -br a
ip r
