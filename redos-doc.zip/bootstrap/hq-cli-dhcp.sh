#!/bin/bash
set -e
nmcli con show
nmcli con mod "Проводное подключение 1" connection.id HQ-CLI
nmcli con mod HQ-CLI ipv4.method auto ipv6.method disabled
nmcli con down HQ-CLI || true
nmcli con up HQ-CLI
ip -br a
ip r
