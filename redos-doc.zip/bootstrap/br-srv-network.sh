#!/bin/bash
set -e
nmcli con show
nmcli con mod "Проводное подключение 1" connection.id BR-SRV
nmcli con mod BR-SRV ipv4.method manual ipv4.addresses 192.168.30.2/28 ipv4.gateway 192.168.30.1 ipv4.dns 192.168.100.2 ipv6.method disabled
nmcli con up BR-SRV
ip -br a
ip r
